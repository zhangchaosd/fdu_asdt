create database `student` default character set utf8 collate utf8_general_ci;
